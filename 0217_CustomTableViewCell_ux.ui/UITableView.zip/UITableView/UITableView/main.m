//
//  main.m
//  UITableView
//
//  Created by Hanson Jung on 2017. 2. 17..
//  Copyright © 2017년 Hanson Jung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
